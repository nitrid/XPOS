import $ from 'jquery'
import * as Site from 'Site'

$(() => {
  Site.run()
})
